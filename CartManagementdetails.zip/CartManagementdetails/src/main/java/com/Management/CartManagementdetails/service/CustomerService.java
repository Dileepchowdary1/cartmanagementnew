package com.Management.CartManagementdetails.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Management.CartManagementdetails.dto.CustomerDto;
import com.Management.CartManagementdetails.dto.CustomerGetDto;
import com.Management.CartManagementdetails.dto.ProductGetDto;
import com.Management.CartManagementdetails.entity.Customer;
import com.Management.CartManagementdetails.mapper.Mapper;
import com.Management.CartManagementdetails.repository.CustomerRepository;

@Service
public class CustomerService {
	
	
	public static final Logger logger = LogManager.getLogger(CustomerService.class);
	@Autowired
	CustomerRepository customerRepository;

	public long createCustomer(CustomerDto dto) {
		try {
			Customer customer = new Customer();
			customer.setCustomerName(dto.getCustomerName());
			customer.setCustomerRegion(dto.getCustomerRegion());
			Customer response = customerRepository.save(customer);
			return response.getCustomerId();
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public List<CustomerGetDto> getAllCustomers() {
		try {
			List<Customer> allCustomers = customerRepository.findAll();
			List<CustomerGetDto> response = Mapper.INSTANCE.getAllCustomersToEntity(allCustomers);
			logger.info("{} <<:getAllCustomers:Response:{}", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return new ArrayList<>();
		}
	}
	
	public long deleteCustomerById(Long customerId) {
		try {
			logger.info("{} >> deleteCustomerById:[{}],", customerId);
			customerRepository.deleteById(customerId);
			return customerId;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}


	public long updateCustomers(CustomerGetDto updateDto) {
		Customer cust = null;
		try {
			if (updateDto.getCustomerId() != null && updateDto.getCustomerId() > 0) {
				cust = customerRepository.getOne(updateDto.getCustomerId());
			}
			if (cust != null) {
				Customer custDto = Mapper.INSTANCE.updateDtoToCustomer(updateDto);
				logger.info("{}<<:updateCustomers:[{}]", custDto);
				custDto = customerRepository.saveAndFlush(custDto);
				return custDto.getCustomerId();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public CustomerGetDto getCustomerById(Long customerId) {
		try {
			Customer response=customerRepository.getOne(customerId);
			if(response!=null) {
				CustomerGetDto dto=new CustomerGetDto(response.getCustomerId(),response.getCustomerName(),
						response.getCustomerRegion());
				logger.info("{} <<:getOrdersById:Response:{}", dto);
				return dto;
			}else {
				logger.info("Customer is null for customerId: {}", customerId);
				return null;
			}
		} catch (Exception e) {
			logger.error("Exception: {}", e.getMessage());
			return new CustomerGetDto();
		}
		
	}
	
}
