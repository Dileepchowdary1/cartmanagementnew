package com.Management.CartManagementdetails.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Management.CartManagementdetails.dto.CartGetDto;
import com.Management.CartManagementdetails.entity.Cart;
import com.Management.CartManagementdetails.entity.Customer;
import com.Management.CartManagementdetails.mapper.Mapper;
import com.Management.CartManagementdetails.repository.CartRepository;
import com.Management.CartManagementdetails.repository.CustomerRepository;

@Service
public class CartService {

	public static final Logger logger = LogManager.getLogger(CartService.class);

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private CartRepository cartRepository;

	public long createCart(Long customerId, Double totalAmount) {
		try {
			Customer customer = customerRepository.getOne(customerId);
			Cart existingCart = cartRepository.findByCustomerId(customerId);
			existingCart.setTotalAmount(totalAmount);
			if (existingCart != null) {
				return existingCart.getCustomer().getCustomerId();
			} else {
				Cart saveCart = createCart(customer);
				return saveCart.getCartId();
			}
		} catch (Exception e) {
			logger.error("Error creating for customer {}: {}", customerId, e.getMessage(), e);
			return 0;
		}
	}

	private Cart createCart(Customer customer) {
		Cart cart = new Cart();
		cart.setCustomer(customer);
		return cartRepository.save(cart);
	}

	public List<CartGetDto> getAllCart() {
		try {
			List<Object[]> carts = cartRepository.getAllCarts();
			List<CartGetDto> response = carts.stream().map(cartData -> {
				Long customerId = (Long) cartData[0];
				Long cartId = (Long) cartData[1];
				Double totalAmount = (Double) cartData[2];
				return new CartGetDto(customerId, cartId, totalAmount);
			}).collect(Collectors.toList());
			logger.info("{} <<:getAllCart:Response:{}", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return new ArrayList<>();
		}
	}

	public long updateCart(CartGetDto updateDto) {
		Cart cart = null;
		try {
			if (updateDto.getCartId() != null && updateDto.getCartId() > 0) {
				cart = cartRepository.getOne(updateDto.getCartId());
				System.out.println("-->> "+cart);
				if (cart != null) {
					Customer customer = customerRepository.getOne(updateDto.getCustomerId());
					System.out.println("customer-->> "+customer);
					if (customer == null) {
						throw new EntityNotFoundException("Customer not found with ID: " + updateDto.getCustomerId());
					}
					Cart dto = Mapper.INSTANCE.updateDtoToCart(updateDto);
					dto.setCustomer(customer);
					dto.setTotalAmount(updateDto.getTotalAmount());
					logger.info("{}<<:updateCart:[{}]", dto);
					dto=cartRepository.saveAndFlush(dto);
					return dto.getCartId();
				}
			}
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public long deleteCartById(Long cartId) {
		try {
			logger.info("{} >> deleteCartById:[{}],", cartId);
			cartRepository.deleteById(cartId);
			return cartId;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public CartGetDto getByCartId(Long cartId) {
		try {
			Cart cart =cartRepository.getOne(cartId);
			if(cart.getCustomer()!=null) {
				CartGetDto resposne=new CartGetDto(cart.getCustomer().getCustomerId(),cart.getCartId(),cart.getTotalAmount());
				logger.info("{} <<:getByCartId:Response:{}", resposne);
				return resposne;
			}else {
				logger.info("Customer is null for MobileId: {}", cartId);
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return null;
		}
	}
}
