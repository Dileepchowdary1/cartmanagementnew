package com.Management.CartManagementdetails.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Management.CartManagementdetails.dto.ProductGetDto;
import com.Management.CartManagementdetails.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product,Long>{
	
	
	@Query("select tbl from Product tbl where tbl.productId=:productId")
	ProductGetDto getProductByProductId(@Param("productId")Long productId);


}
