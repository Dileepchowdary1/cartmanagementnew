package com.Management.CartManagementdetails.service;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.Management.CartManagementdetails.dto.RegionOrderReport;
import com.Management.CartManagementdetails.entity.PurchaseOrder;

@Component
public class OrderReportScheduledJob {
	
	
	public static final Logger logger = LogManager.getLogger(OrderReportScheduledJob.class);
	
	@Autowired
    private OrderService orderService;

    @Scheduled(cron = "0 0 1 * * ?")  
    public void generateOrderReport() {
        try {
            LocalDateTime now = LocalDateTime.now();
            List<PurchaseOrder> submittedOrders = orderService.getOrdersSubmittedToday(now);
            List<PurchaseOrder> cancelledOrders = orderService.getCancelledOrdersToday(now);
            List<RegionOrderReport> regionOrderReports = orderService.getOrderReportPerRegion();
             logger.info("Submitted Orders Today: {}", submittedOrders);
             logger.info("Cancelled Orders Today: {}", cancelledOrders);
             logger.info("Order Report Per Region: {}", regionOrderReports);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
