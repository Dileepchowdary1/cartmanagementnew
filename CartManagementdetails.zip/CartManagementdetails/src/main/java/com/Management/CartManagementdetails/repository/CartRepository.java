package com.Management.CartManagementdetails.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Management.CartManagementdetails.entity.Cart;


@Repository
public interface CartRepository extends JpaRepository<Cart,Long>{

	@Query("select tbl from Cart tbl where tbl.customer.customerId=:customerId")
	Cart findByCustomerId(@Param("customerId")Long customerId);


	@Query("select tbl.customer.customerId,tbl.cartId,tbl.totalAmount from Cart tbl ")
	List<Object[]> getAllCarts();


}
