package com.Management.CartManagementdetails.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.Management.CartManagementdetails.dto.CustomerGetDto;
import com.Management.CartManagementdetails.entity.Customer;



@Repository
public interface CustomerRepository extends JpaRepository<Customer,Long>{

	@Query("select tbl from Customer tbl where tbl.customerId=:customerId")
	CustomerGetDto getCustomerByCustomerId(@Param("customerId")Long customerId);
	

}
