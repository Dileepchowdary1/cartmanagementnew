package com.Management.CartManagementdetails.dto;

import java.time.LocalDateTime;

public class CartItemCrtDto {

	
	private Long cartId;
	private Long productId; 
	private int quantity;
	private Long customerId;
	 private LocalDateTime lastModified;
	
	public CartItemCrtDto(Long cartId, Long productId, int quantity, Long customerId, LocalDateTime lastModified) {
		super();
		this.cartId = cartId;
		this.productId = productId;
		this.quantity = quantity;
		this.customerId = customerId;
		this.lastModified = lastModified;
	}
	public CartItemCrtDto() {
		super();
	}
	public Long getCartId() {
		return cartId;
	}
	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public LocalDateTime getLastModified() {
		return lastModified;
	}
	public void setLastModified(LocalDateTime lastModified) {
		this.lastModified = lastModified;
	}
	@Override
	public String toString() {
		return "CartItemCrtDto [cartId=" + cartId + ", productId=" + productId + ", quantity=" + quantity
				+ ", customerId=" + customerId + ", lastModified=" + lastModified + "]";
	}
}
