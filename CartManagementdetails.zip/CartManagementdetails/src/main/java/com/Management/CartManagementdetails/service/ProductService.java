package com.Management.CartManagementdetails.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Management.CartManagementdetails.dto.ProductCrtDto;
import com.Management.CartManagementdetails.dto.ProductGetDto;
import com.Management.CartManagementdetails.entity.Product;
import com.Management.CartManagementdetails.mapper.Mapper;
import com.Management.CartManagementdetails.repository.ProductRepository;

@Service
public class ProductService {
	public static final Logger logger = LogManager.getLogger(ProductService.class);
	
	@Autowired
	ProductRepository productRepository;
	
	public long saveProducts(ProductCrtDto dto) {
		try {
			logger.info("{} >> ProductCrtDto:[{}],", dto);
			Product product = new Product();
			product.setName(dto.getName());
			product.setCategory(dto.getCategory());
			product.setDescription(dto.getDescription());
			product.setCost(dto.getCost());
			product.setPrice(dto.getPrice());
			Product response=productRepository.save(product);
			logger.info("{} >> saveProducts:[{}],", response);
			return response.getProductId();
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	
	public List<ProductGetDto> getAllProducts() {
		try {
			List<Product> allProducts = productRepository.findAll();
			List<ProductGetDto> response = Mapper.INSTANCE.getAllProductToEntity(allProducts);
			logger.info("{} <<:getAllCustomers:Response:{}", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return new ArrayList<>();
		}
	}

	public ProductGetDto getProductsById(Long productId) {
		try {
			Product response=productRepository.getOne(productId);
			if(response!=null) {
				ProductGetDto dto=new ProductGetDto(response.getProductId(), response.getCategory(),
						response.getName(), response.getDescription(),response.getPrice(),response.getCost());
				logger.info("{} <<:getProductsById:Response:{}", dto);
				return dto;
			}else {
				logger.info("Product is null for customerId: {}", productId);
				return null;
			}
		} catch (Exception e) {
			logger.error("Exception: {}", e.getMessage());
			return new ProductGetDto();
		}
		
	}


	public long updateProduct(ProductGetDto updateDto) {
		Product product = null;
		try {
			if (updateDto.getProductId() != null && updateDto.getProductId() > 0) {
				product = productRepository.getOne(updateDto.getProductId());
			}
			if (product != null) {
				Product productDto = Mapper.INSTANCE.updateDtoToProduct(updateDto);
				productDto = productRepository.saveAndFlush(productDto);
				logger.info("{}<<:updateProduct:[{}]", productDto);
				return productDto.getProductId();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}


	
	public long deleteProductById(Long customerId) {
		try {
			logger.info("{} >> deleteProductById:[{}],", customerId);
			productRepository.deleteById(customerId);
			return customerId;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

}
