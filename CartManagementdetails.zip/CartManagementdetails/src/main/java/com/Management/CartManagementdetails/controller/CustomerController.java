package com.Management.CartManagementdetails.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Management.CartManagementdetails.dto.CustomerDto;
import com.Management.CartManagementdetails.dto.CustomerGetDto;
import com.Management.CartManagementdetails.dto.ProductGetDto;
import com.Management.CartManagementdetails.dto.ResponseDto;
import com.Management.CartManagementdetails.service.CustomerService;

@RestController
@RequestMapping("customers/")
public class CustomerController {
	
	public static final Logger logger = LogManager.getLogger(CustomerController.class);
	
	@Autowired
	CustomerService customerService;
	
	@PostMapping(path = "createCustomers", produces = { "application/json", "application/xml" })
	    public ResponseEntity<ResponseDto> createCustomerCart(@RequestBody CustomerDto dto) {
		 ResponseDto response=null;
	        try {
	            long id = customerService.createCustomer(dto);
	            if (id > 0) {
					response = new ResponseDto(id, "Customer Created Successfully");
					logger.info("{} <<:saveCustomer:Response:{}", response);
					return new ResponseEntity<>(response, HttpStatus.CREATED);
				} else {
					response = new ResponseDto(id, "Customer Created failed");
					logger.info("{} <<:saveCustomer:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				}
	        } catch (Exception e) {
	            logger.error("Error creating customer cart", e);
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }
	 
	 
	 @GetMapping(path = "getallcustomers", produces = { "application/json", "application/xml" })
		public ResponseEntity<List<CustomerGetDto>> getAllCustomers() {
			try {
				List<CustomerGetDto> response = customerService.getAllCustomers();
				logger.info("{} <<:getAllCustomers:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Exception:{}", e.getMessage());
				return ResponseEntity.status(HttpStatus.OK).body(new ArrayList<>());
			}
		}
	 
	 @PutMapping(path = "updatecustomer/{customerId}", produces = { "application/json", "application/xml" })
		public ResponseEntity<ResponseDto> updateCustomer(@RequestBody CustomerGetDto updateDto) {
			ResponseDto response = null;
			try {
				long id = customerService.updateCustomers(updateDto);
				if (id > 0) {
					response = new ResponseDto(id, "Customer update Successfully");
					logger.info("{} <<:update:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				} else {
					response = new ResponseDto(id, "Customer update failed");
					logger.info("{} <<:update:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Exception: {}", e.getMessage());
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
			}
		}

		@DeleteMapping(path = "deletecustomer/{customerId}", produces = { "application/json", "application/xml" })
		public ResponseEntity<ResponseDto> deleteCustomer(@PathVariable("customerId") Long customerId) {
			ResponseDto response = null;
			try {
				long id = customerService.deleteCustomerById(customerId);
				if (id > 0) {
					response = new ResponseDto(id, "Customer deleted Successfully");
					logger.info("{} <<:deleteCustomer:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				} else {
					response = new ResponseDto(id, "Customer fail to delete");
					logger.info("{} <<:deleteCustomer:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Exception: {}", e.getMessage());
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
			}
		}
		@GetMapping(path = "/getById/{customerId}", produces = { "application/json", "application/xml" })
		public ResponseEntity<CustomerGetDto> getCustomerById(@PathVariable("customerId") Long customerId) {
	        try {
	        	CustomerGetDto response = customerService.getCustomerById(customerId);
	            if (response != null) {
	                logger.info(">>getCustomerById:[{}]", response);
	                return ResponseEntity.status(HttpStatus.OK).body(response);
	            } else {
	                logger.info("{} <<:getCustomerById:Response:{}", response);
	                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	        }
	    }
	 
}
