package com.Management.CartManagementdetails.dto;

	public class CustomerDto {
	    private String customerName;
	    private String customerRegion;
		public CustomerDto(String customerName, String customerRegion) {
			super();
			this.customerName = customerName;
			this.customerRegion = customerRegion;
		}
		public CustomerDto() {
			super();
		}
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}
		public String getCustomerRegion() {
			return customerRegion;
		}
		public void setCustomerRegion(String customerRegion) {
			this.customerRegion = customerRegion;
		}
		@Override
		public String toString() {
			return "CustomerDto [customerName=" + customerName + ", customerRegion="
					+ customerRegion + "]";
		}

}
