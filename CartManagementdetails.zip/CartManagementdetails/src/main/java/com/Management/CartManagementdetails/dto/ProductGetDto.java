package com.Management.CartManagementdetails.dto;

public class ProductGetDto {
	private Long productId;
	
	private String category;

    private String name;

    private String description;

    private Double price;

    private Double cost;

	public ProductGetDto(Long productId, String category, String name, String description, Double price, Double cost) {
		super();
		this.productId = productId;
		this.category = category;
		this.name = name;
		this.description = description;
		this.price = price;
		this.cost = cost;
	}

	public ProductGetDto() {
		super();
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "ProductGetDto [productId=" + productId + ", category=" + category + ", name=" + name + ", description="
				+ description + ", price=" + price + ", cost=" + cost + "]";
	}
    
}
