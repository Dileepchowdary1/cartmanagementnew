package com.Management.CartManagementdetails.mapper;

import java.util.List;

import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.Management.CartManagementdetails.dto.CartGetDto;
import com.Management.CartManagementdetails.dto.CustomerGetDto;
import com.Management.CartManagementdetails.dto.ProductGetDto;
import com.Management.CartManagementdetails.entity.Cart;
import com.Management.CartManagementdetails.entity.Customer;
import com.Management.CartManagementdetails.entity.Product;


@org.mapstruct.Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = "String")
public interface Mapper {
	
	Mapper INSTANCE = Mappers.getMapper(Mapper.class);

	List<ProductGetDto> getAllProductToEntity(List<Product> allProducts);

	Product updateDtoToProduct(ProductGetDto updateDto);

	List<CustomerGetDto> getAllCustomersToEntity(List<Customer> allCustomers);

	Customer updateDtoToCustomer(CustomerGetDto updateDto);

	Cart updateDtoToCart(CartGetDto updateDto);

}
