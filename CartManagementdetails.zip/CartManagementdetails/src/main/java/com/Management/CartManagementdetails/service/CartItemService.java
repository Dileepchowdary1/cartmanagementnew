package com.Management.CartManagementdetails.service;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Management.CartManagementdetails.dto.CartItemCrtDto;
import com.Management.CartManagementdetails.dto.CartItemUpdateDto;
import com.Management.CartManagementdetails.entity.Cart;
import com.Management.CartManagementdetails.entity.CartItem;
import com.Management.CartManagementdetails.entity.Customer;
import com.Management.CartManagementdetails.entity.Product;
import com.Management.CartManagementdetails.repository.CartItemRepository;
import com.Management.CartManagementdetails.repository.CartRepository;
import com.Management.CartManagementdetails.repository.CustomerRepository;
import com.Management.CartManagementdetails.repository.ProductRepository;

@Service
public class CartItemService {

	public static final Logger logger = LogManager.getLogger(CartItemService.class);

	@Autowired
	ProductRepository productRepository;

	@Autowired
	CartItemRepository cartItemRepo;
	
	@Autowired
	CartRepository cartRepository;
	
	@Autowired
	CustomerRepository customerRepository;

	public long addProductToCart(CartItemCrtDto crtDto) {
		try {
			logger.info("{} >> CartItemCrtDto:[{}],", crtDto);
			CartItem cartItem = new CartItem();
			Cart cart=cartRepository.getOne(crtDto.getCartId());
			cartItem.setCart(cart);
			Product product=productRepository.getOne(crtDto.getProductId());
			cartItem.setProduct(product);
			Customer customer=customerRepository.getOne(crtDto.getCustomerId());
			cartItem.setCustomer(customer);
			cartItem.setLastModified(crtDto.getLastModified());
			cartItem.setQuantity(crtDto.getQuantity());
			CartItem response = cartItemRepo.save(cartItem);
			logger.info("{} >> addProductToCart:[{}],", response);
			return response.getCartItemId();
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public long changeProductQuantity(CartItemUpdateDto dto) {
		CartItem cart = null;
		try {
			logger.info("{} >> CartItemUpdateDto:[{}],", dto);
			if (dto.getCartItemId() != null && dto.getCartItemId() > 0) {
				cart = cartItemRepo.getOne(dto.getCartItemId());
			}
			if (cart != null) {
				CartItem cartItem = new CartItem();
				cartItem.setQuantity(dto.getQuantity());
				CartItem response = cartItemRepo.save(cartItem);
				logger.info("{} >> changeProductQuantity:[{}],", response);
				return response.getCartItemId();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public long deleteCartItemById(Long cartItemId) {
		try {
			logger.info("{} >> deleteCartItemById:[{}],", cartItemId);
			cartItemRepo.deleteById(cartItemId);
			return cartItemId;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}
	
	public void checkPromotionAndClearCart(Long customerId) {
        try {
            Double purchaseAmount = cartItemRepo.calculateTotalPurchaseAmountByCustomerId(customerId);

            if (purchaseAmount.compareTo(Double.valueOf(200)) > 0) {
                Double discountPercentage = Double.valueOf(5);
                Double discountAmount = purchaseAmount * (discountPercentage / 100);
                Double discountedAmount = purchaseAmount - discountAmount;
                logger.info("Customer with ID {}: Eligible for a 5% discount. Original Purchase Amount: {}, Discounted Amount: {}",
                        customerId, purchaseAmount, discountedAmount);
                cartItemRepo.deleteByCustomerId(customerId);
                logger.info("Cart cleared for customer with ID {}: Promotion applied.", customerId);
            } else {
                logger.info("Customer with ID {} is not eligible for promotion.", customerId);
            }
        } catch (Exception e) {
        	e.printStackTrace();
            logger.error("Error processing promotion check and cart clearing", e);
        }
    }
	
	
	public void clearInactiveCarts(Long customerId) {
        try {
            LocalDateTime threshold = LocalDateTime.now().minusHours(2);
            List<CartItem> inactiveCarts = cartItemRepo.findByLastActivityBefore(customerId,threshold);
            for (CartItem cartItem : inactiveCarts) {
            	cartItemRepo.delete(cartItem);
            }
            logger.info("Cleared {} inactive carts at: {}", inactiveCarts.size(), LocalDateTime.now());
        } catch (Exception e) {
            logger.error("Error while clearing inactive carts: {}", e.getMessage(), e);
        }
    }

	 public List<Long> findInactiveCustomers(LocalDateTime threshold) {
        return cartItemRepo.findInactiveCustomerIds(threshold);
    }
}
