package com.Management.CartManagementdetails.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Management.CartManagementdetails.dto.RegionOrderReport;
import com.Management.CartManagementdetails.entity.Customer;
import com.Management.CartManagementdetails.entity.PurchaseOrder;
import com.Management.CartManagementdetails.repository.CustomerRepository;
import com.Management.CartManagementdetails.repository.PurchaseOrderRepository;

@Service
public class OrderService {
	
	public static final Logger logger = LogManager.getLogger(OrderService.class);

	@Autowired
    private PurchaseOrderRepository orderRepository;
	
	@Autowired
	CustomerRepository customerRepository;

    public List<PurchaseOrder> getOrdersSubmittedToday(LocalDateTime today) {
        LocalDateTime startOfDay = today.withHour(0).withMinute(0).withSecond(0);
        LocalDateTime endOfDay = today.withHour(23).withMinute(59).withSecond(59);

        return orderRepository.findByOrderDateTimeBetween(startOfDay, endOfDay);
    }

	public List<PurchaseOrder> getCancelledOrdersToday(LocalDateTime now) {
        LocalDate today = LocalDate.now();
        return orderRepository.findByOrderStatusAndOrderDateTimeBetween("CANCELLED", today.atStartOfDay(), today.atTime(23, 59, 59));
    }
	public List<RegionOrderReport> getOrderReportPerRegion() {
        List<Customer> customers = customerRepository.findAll();
        Map<String, RegionOrderReport> regionOrderReportMap = new HashMap<>();
        for (Customer customer : customers) {
            String region = customer.getCustomerRegion(); 
            List<PurchaseOrder> orders = orderRepository.findByCustomerAndOrderDateTimeBetween(
                    customer,
                    LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0),
                    LocalDateTime.now()
            );
            RegionOrderReport regionOrderReport = regionOrderReportMap.getOrDefault(region, new RegionOrderReport(region));
            regionOrderReport.addOrders(orders);
            regionOrderReportMap.put(region, regionOrderReport);
        }
        return regionOrderReportMap.values().stream().collect(Collectors.toList());
    }
}
