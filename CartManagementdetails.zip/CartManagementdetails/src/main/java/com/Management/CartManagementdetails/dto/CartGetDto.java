package com.Management.CartManagementdetails.dto;

public class CartGetDto {
	
	 private Long customerId;
	 private Long cartId;
	 private Double totalAmount;
	public CartGetDto(Long customerId, Long cartId, Double totalAmount) {
		super();
		this.customerId = customerId;
		this.cartId = cartId;
		this.totalAmount = totalAmount;
	}
	public CartGetDto() {
		super();
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Long getCartId() {
		return cartId;
	}
	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	@Override
	public String toString() {
		return "CartGetDto [customerId=" + customerId + ", cartId=" + cartId + ", totalAmount=" + totalAmount + "]";
	}
	 
	 

}
