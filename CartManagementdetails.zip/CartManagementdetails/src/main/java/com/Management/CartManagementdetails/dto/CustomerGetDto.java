package com.Management.CartManagementdetails.dto;

public class CustomerGetDto {
	
	private Long customerId;
	private String customerName;
    private String customerRegion;
	public CustomerGetDto(Long customerId, String customerName, String customerRegion) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerRegion = customerRegion;
	}
	public CustomerGetDto() {
		super();
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerRegion() {
		return customerRegion;
	}
	public void setCustomerRegion(String customerRegion) {
		this.customerRegion = customerRegion;
	}
	@Override
	public String toString() {
		return "CustomerGetDto [customerId=" + customerId + ", customerName=" + customerName + ", customerRegion="
				+ customerRegion + "]";
	}

}
