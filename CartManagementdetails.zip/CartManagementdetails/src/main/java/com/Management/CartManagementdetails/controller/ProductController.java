package com.Management.CartManagementdetails.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Management.CartManagementdetails.dto.ProductCrtDto;
import com.Management.CartManagementdetails.dto.ProductGetDto;
import com.Management.CartManagementdetails.dto.ResponseDto;
import com.Management.CartManagementdetails.service.ProductService;

@RestController
@RequestMapping("OrderCustomers/")
public class ProductController {

	public static final Logger logger = LogManager.getLogger(ProductController.class);
	@Autowired
	private ProductService productService;

	@PostMapping(path = "saveproducts", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> saveProducts(@RequestBody ProductCrtDto crtDto) {
		ResponseDto response = null;
		try {
			long id = productService.saveProducts(crtDto);
			if (id > 0) {
				response = new ResponseDto(id, "Product Created Successfully");
				logger.info("{} <<:saveProducts:Response:{}", response);
				return new ResponseEntity<>(response, HttpStatus.CREATED);
			} else {
				response = new ResponseDto(id, "Product Created failed");
				logger.info("{} <<:saveProducts:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error saving products", e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@GetMapping(path = "getallproducts", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<ProductGetDto>> getAllProducts() {
		try {
			List<ProductGetDto> response = productService.getAllProducts();
			logger.info("{} <<:getAllProducts:Response:{}", response);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception:{}", e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(new ArrayList<>());
		}
	}
	
	
	@GetMapping(path = "/getById/{productId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ProductGetDto> getProductsById(@PathVariable("productId") Long productId) {
        try {
        	ProductGetDto response = productService.getProductsById(productId);
            if (response != null) {
                logger.info(">>getProductsById:[{}]", response);
                return ResponseEntity.status(HttpStatus.OK).body(response);
            } else {
                logger.info("{} <<:getProductsById:Response:{}", response);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
	
	@PutMapping(path = "updateproducts/{productId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> updateProduct(@RequestBody ProductGetDto updateDto) {
		ResponseDto response = null;
		try {
			long id = productService.updateProduct(updateDto);
			if (id > 0) {
				response = new ResponseDto(id, "Product update Successfully");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "Product update failed");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
	
	@DeleteMapping(path = "deleteproduct/{productId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> deleteProduct(@PathVariable("productId") Long productId) {
		ResponseDto response = null;
		try {
			long id = productService.deleteProductById(productId);
			if (id > 0) {
				response = new ResponseDto(id, "Product deleted Successfully");
				logger.info("{} <<:deleteProduct:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "Product fail to delete");
				logger.info("{} <<:deleteProduct:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
	
}
