package com.Management.CartManagementdetails.dto;

public class ResponseDto {

	
	private long id;
	private String statusMsg;

    public ResponseDto() {
    }

    public ResponseDto(long id,String statusMsg) {
        this.statusMsg = statusMsg;
        this.id=id;
    }

    public String getStatusMsg() {
        return statusMsg;
    }

    public void setStatusMsg(String statusMsg) {
        this.statusMsg = statusMsg;
    }

    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "ResponseDto [id=" + id + ", statusMsg=" + statusMsg + "]";
	}

}
