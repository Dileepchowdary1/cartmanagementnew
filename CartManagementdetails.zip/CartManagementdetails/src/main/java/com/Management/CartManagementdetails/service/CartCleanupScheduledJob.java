package com.Management.CartManagementdetails.service;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class CartCleanupScheduledJob  {
	
	public static final Logger logger = LogManager.getLogger(CartCleanupScheduledJob.class);

	@Autowired
    private CartItemService cartItemService;

    @Scheduled(fixedRate = 1800000)
    public void clearInactiveCarts() {
        try {
            LocalDateTime threshold = LocalDateTime.now().minusHours(2);
            List<Long> inactiveCustomerIds = cartItemService.findInactiveCustomers(threshold);
            for (Long customerId : inactiveCustomerIds) {
            	cartItemService.clearInactiveCarts(customerId);
            }
             logger.info("Cleared inactive carts at: {}", LocalDateTime.now());
        } catch (Exception e) {
            e.printStackTrace();
             logger.error("Error while clearing inactive carts: {}", e.getMessage(), e);
        }
    }

}
