package com.Management.CartManagementdetails.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="purchaseOrder")
public class PurchaseOrder {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="order_id")
    private Long orderId;

	@Column(name="orderdate_time")
    private LocalDateTime orderDateTime;

	@Column(name="order_status")
    private String orderStatus;
	
	@Column(name="total_order_amount")
	private double totalOrderAmount;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;


	public PurchaseOrder(Long orderId, LocalDateTime orderDateTime, String orderStatus, double totalOrderAmount,
			Customer customer) {
		super();
		this.orderId = orderId;
		this.orderDateTime = orderDateTime;
		this.orderStatus = orderStatus;
		this.totalOrderAmount = totalOrderAmount;
		this.customer = customer;
	}

	public PurchaseOrder() {
		super();
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public LocalDateTime getOrderDateTime() {
		return orderDateTime;
	}

	public void setOrderDateTime(LocalDateTime orderDateTime) {
		this.orderDateTime = orderDateTime;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	

	public double getTotalOrderAmount() {
		return totalOrderAmount;
	}

	public void setTotalOrderAmount(double totalOrderAmount) {
		this.totalOrderAmount = totalOrderAmount;
	}

	@Override
	public String toString() {
		return "PurchaseOrder [orderId=" + orderId + ", orderDateTime=" + orderDateTime + ", orderStatus=" + orderStatus
				+ ", totalOrderAmount=" + totalOrderAmount + ", customer=" + customer + "]";
	}

}
