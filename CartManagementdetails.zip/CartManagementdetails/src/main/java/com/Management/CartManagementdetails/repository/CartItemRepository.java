package com.Management.CartManagementdetails.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Management.CartManagementdetails.entity.CartItem;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem,Long>{
	
	

	@Modifying
    @Transactional
    @Query("DELETE FROM CartItem c WHERE c.customer.customerId = :customerId")
    void deleteByCustomerId(@Param("customerId") Long customerId);

	  
	  @Query("SELECT SUM(c.product.price * c.quantity) FROM CartItem c WHERE c.customer.customerId = :customerId")
	    Double calculateTotalPurchaseAmountByCustomerId(@Param("customerId") Long customerId);

	
	 @Query("SELECT DISTINCT ci.customer.customerId FROM CartItem ci WHERE ci.lastModified < :threshold")
	    List<Long> findInactiveCustomerIds(@Param("threshold") LocalDateTime threshold);

	
	 @Query("SELECT ci FROM CartItem ci WHERE ci.customer.id = :customerId AND ci.lastModified < :threshold")
	    List<CartItem> findByLastActivityBefore(@Param("customerId") Long customerId, @Param("threshold") LocalDateTime threshold);

	    @Query("DELETE FROM CartItem ci WHERE ci.customer.id = :customerId AND ci.lastModified < :threshold")
	    void delete(@Param("customerId") Long customerId, @Param("threshold") LocalDateTime threshold);
	 



}
