package com.Management.CartManagementdetails.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Management.CartManagementdetails.entity.Customer;
import com.Management.CartManagementdetails.entity.PurchaseOrder;

@Repository
public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Long> {

	@Query("SELECT po FROM PurchaseOrder po WHERE po.orderDateTime BETWEEN :startOfDay AND :endOfDay")
	List<PurchaseOrder> findByOrderDateTimeBetween(@Param("startOfDay") LocalDateTime startOfDay,
			@Param("endOfDay") LocalDateTime endOfDay);

	
	 @Query("SELECT po FROM PurchaseOrder po WHERE po.orderStatus = :orderStatus AND po.orderDateTime BETWEEN :startDateTime AND :endDateTime")
	    List<PurchaseOrder> findByOrderStatusAndOrderDateTimeBetween(@Param("orderStatus") String orderStatus,
	                                                                @Param("startDateTime") LocalDateTime startDateTime,
	                                                                @Param("endDateTime") LocalDateTime endDateTime);

	 @Query("SELECT po FROM PurchaseOrder po WHERE po.customer = :customer AND po.orderDateTime BETWEEN :startDateTime AND :endDateTime")
	    List<PurchaseOrder> findByCustomerAndOrderDateTimeBetween(@Param("customer") Customer customer,
	                                                              @Param("startDateTime") LocalDateTime startDateTime,
	                                                              @Param("endDateTime") LocalDateTime endDateTime);


}
