package com.Management.CartManagementdetails.dto;

import java.util.List;

import com.Management.CartManagementdetails.entity.PurchaseOrder;

public class RegionOrderReport {

	
	  private String region;
	    private int totalOrders;
	    private double totalOrderAmount;
	    private List<PurchaseOrder> orders;

	    public RegionOrderReport(String region) {
	        this.region = region;
	        this.totalOrders = 0;
	        this.totalOrderAmount = 0.0;
	    }

	    public String getRegion() {
	        return region;
	    }

	    public int getTotalOrders() {
	        return totalOrders;
	    }

	    public double getTotalOrderAmount() {
	        return totalOrderAmount;
	    }

	    public List<PurchaseOrder> getOrders() {
	        return orders;
	    }

	    
		public RegionOrderReport() {
			super();
		}

		public RegionOrderReport(String region, int totalOrders, double totalOrderAmount, List<PurchaseOrder> orders) {
			super();
			this.region = region;
			this.totalOrders = totalOrders;
			this.totalOrderAmount = totalOrderAmount;
			this.orders = orders;
		}

		@Override
		public String toString() {
			return "RegionOrderReport [region=" + region + ", totalOrders=" + totalOrders + ", totalOrderAmount="
					+ totalOrderAmount + ", orders=" + orders + "]";
		}
		
		 public void addOrders(List<PurchaseOrder> newOrders) {
		        if (newOrders != null && !newOrders.isEmpty()) {
		            this.orders.addAll(newOrders);
		            this.totalOrders += newOrders.size();
		            this.totalOrderAmount += newOrders.stream().mapToDouble(order -> order.getTotalOrderAmount()).sum();
		        }
		    }

	    
}
