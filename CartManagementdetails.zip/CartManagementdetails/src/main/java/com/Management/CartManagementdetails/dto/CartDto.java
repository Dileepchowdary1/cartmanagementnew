package com.Management.CartManagementdetails.dto;

public class CartDto {
	
	private Long customerId;

    private String customerRegion;

	public CartDto(Long customerId, String customerRegion) {
		super();
		this.customerId = customerId;
		this.customerRegion = customerRegion;
	}

	public CartDto() {
		super();
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerRegion() {
		return customerRegion;
	}

	public void setCustomerRegion(String customerRegion) {
		this.customerRegion = customerRegion;
	}

	@Override
	public String toString() {
		return "CartDto [customerId=" + customerId + ", customerRegion=" + customerRegion + "]";
	}
    
    

}
