package com.Management.CartManagementdetails.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Management.CartManagementdetails.dto.CartItemCrtDto;
import com.Management.CartManagementdetails.dto.CartItemUpdateDto;
import com.Management.CartManagementdetails.dto.ResponseDto;
import com.Management.CartManagementdetails.service.CartItemService;


@RestController
@RequestMapping("CartItem/")
public class CartItemController {
	
	public static final Logger logger = LogManager.getLogger(CartItemController.class);

	@Autowired
	CartItemService cartItemService;
	
	@PostMapping(path = "addProducttocart", produces = { "application/json", "application/xml" })
    public ResponseEntity<ResponseDto> addProductToCart(@RequestBody CartItemCrtDto crtDto) {
		ResponseDto response = null;
        try {
        	long id=cartItemService.addProductToCart(crtDto);
        	if (id > 0) {
				response = new ResponseDto(id, "Cart Created Successfully");
				logger.info("{} <<:addProductToCart:Response:{}", response);
				return new ResponseEntity<>(response, HttpStatus.CREATED);
			} else {
				response = new ResponseDto(id, "Cart Created failed");
				logger.info("{} <<:addProductToCart:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error saving customer", e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
    }
	
	@PutMapping(path = "changeQuantity/{cartItemId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> changeProductQuantity(@RequestBody CartItemUpdateDto updateDto) {
		ResponseDto response = null;
		try {
			long id = cartItemService.changeProductQuantity(updateDto);
			if (id > 0) {
				response = new ResponseDto(id, "CartItem update Successfully");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "CartItem update failed");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
	
	@DeleteMapping(path = "removecartitems/{cartItemId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> deleteCartItem(@PathVariable("cartItemId") Long cartItemId) {
		ResponseDto response = null;
		try {
			long id = cartItemService.deleteCartItemById(cartItemId);
			if (id > 0) {
				response = new ResponseDto(id, "CartItem deleted Successfully");
				logger.info("{} <<:deleteCartItem:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "CartItem fail to delete");
				logger.info("{} <<:deleteCartItem:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
	
	 @PostMapping(path = "checkAndClearCart", produces = { "application/json", "application/xml" })
	    public ResponseEntity<ResponseDto> checkPromotionAndClearCart(@RequestParam Long customerId) {
	        try {
	        	cartItemService.checkPromotionAndClearCart(customerId);
	            ResponseDto response = new ResponseDto(customerId, "Promotion checked successfully, and cart cleared if eligible.");
	            return ResponseEntity.ok(response);
	        }  catch (Exception e) {
	            logger.error("Internal Server Error: {}", e.getMessage(), e);
	            ResponseDto response = new ResponseDto(1, "Internal Server Error");
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
	        }
	    }
	
}
