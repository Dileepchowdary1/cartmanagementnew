package com.Management.CartManagementdetails.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="cart")
public class Cart {
	
	
		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name="cart_id")
	    private Long cartId;

	    @OneToOne
	    @JoinColumn(name = "customer_id")
	    private Customer customer;

	    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, orphanRemoval = true)
	    private List<CartItem> cartItems = new ArrayList<>();

	    private Double totalAmount;

		public Cart(Long cartId, Customer customer, List<CartItem> cartItems, Double totalAmount) {
			super();
			this.cartId = cartId;
			this.customer = customer;
			this.cartItems = cartItems;
			this.totalAmount = totalAmount;
		}

		public Cart() {
			super();
		}


		public Cart(Long cartId) {
			this.cartId=cartId;
		}

		public Long getCartId() {
			return cartId;
		}

		public void setCartId(Long cartId) {
			this.cartId = cartId;
		}

		public Customer getCustomer() {
			return customer;
		}

		public void setCustomer(Customer customer) {
			this.customer = customer;
		}

		public List<CartItem> getCartItems() {
			return cartItems;
		}

		public void setCartItems(List<CartItem> cartItems) {
			this.cartItems = cartItems;
		}

		public Double getTotalAmount() {
			return totalAmount;
		}

		public void setTotalAmount(Double totalAmount) {
			this.totalAmount = totalAmount;
		}

		@Override
		public String toString() {
			return "Cart [cartId=" + cartId + ", customer=" + customer + ", cartItems=" + cartItems + ", totalAmount="
					+ totalAmount + "]";
		}

		
}
