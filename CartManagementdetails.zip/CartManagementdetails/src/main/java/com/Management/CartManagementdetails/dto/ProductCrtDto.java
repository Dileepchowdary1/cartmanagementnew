package com.Management.CartManagementdetails.dto;

public class ProductCrtDto {
	

    private String category;

    private String name;

    private String description;

    private Double price;

    private Double cost;

	public ProductCrtDto(String category, String name, String description, Double price, Double cost) {
		super();
		this.category = category;
		this.name = name;
		this.description = description;
		this.price = price;
		this.cost = cost;
	}

	public ProductCrtDto() {
		super();
	}


	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "ProductCrtDto [category=" + category + ", name=" + name + ", description="
				+ description + ", price=" + price + ", cost=" + cost + "]";
	}
    
}
